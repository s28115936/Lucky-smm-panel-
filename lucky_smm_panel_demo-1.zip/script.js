function selectService(name){document.getElementById('service').value=name;document.querySelector('.order-box').scrollIntoView({behavior:'smooth'});}
function placeOrder(){
 const service=document.getElementById('service').value;
 const link=document.getElementById('link').value.trim();
 const qty=document.getElementById('qty').value;
 const msg=document.getElementById('message');
 if(service==='Select service'||!link||!qty){msg.textContent='कृपया सभी जानकारी भरें।';return;}
 msg.textContent='Demo order सफलतापूर्वक बनाया गया: '+service+' — '+qty+' units.';
}
